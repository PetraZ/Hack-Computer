# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 20:30:12 2017

@author: lenovo
"""


symbols ="{|}|\(|\)|\[|\]|\.|,|;|\+|-|\*|/|&|\||<|>|=|~"

symbol_list = ['{','}','(',')','[',']','.',',',';','+','=','-','*','/','&','|','<','>','~']

key_words_list = ['class','constructor','function','method','field','static','var',
                  'int','char','boolean','void','true','false','null','this','let','do','if','else','while','return']

while_space = [' ', '\n', '\t']











# =============================================================================
# a = re.split('(\+|=)',"x=x+2")
# #['x', '=', 'x', '+', '2']
# print (a)
# 
# b= re.split(',|;\s*', "This,is;a,;    string")
# #['This', 'is', 'a', '', 'string']
# print (b)
# 
# =============================================================================
